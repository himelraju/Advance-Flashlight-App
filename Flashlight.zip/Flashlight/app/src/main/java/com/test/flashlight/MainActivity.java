package com.test.flashlight;

import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.Bundle;
import android.Manifest;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.slider.Slider;
import com.google.android.material.snackbar.Snackbar;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.content.SharedPreferences;
import androidx.preference.PreferenceManager;
import android.graphics.Color;
import android.view.View.OnLongClickListener;
import android.provider.MediaStore;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    private boolean isFlashlightOn = false;
    private CameraManager cameraManager;
    private String cameraId;
    private MaterialButton flashlightButton;
    private Slider brightnessSlider;
    private Handler handler = new Handler(Looper.getMainLooper());
    private TextView batteryLevel;
    private TextView timerText;
    private MaterialButtonToggleGroup modeToggleGroup;
    private boolean isStrobeMode = false;
    private boolean isSosMode = false;
    private int autoOffTimer = 0;
    private Runnable strobeRunnable;
    private Runnable sosRunnable;
    private Runnable timerRunnable;
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private SharedPreferences prefs;
    private View screenLight;
    private long lastShakeTime;
    private static final float SHAKE_THRESHOLD = 800;
    private static final int CAMERA_REQUEST = 1888;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 1);
        }

        initializeComponents();
        
        batteryLevel = findViewById(R.id.batteryLevel);
        timerText = findViewById(R.id.timerText);
        modeToggleGroup = findViewById(R.id.modeToggleGroup);
        
        FloatingActionButton settingsButton = findViewById(R.id.settingsButton);
        settingsButton.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        
        setupModes();
        updateBatteryLevel();
        
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        prefs = PreferenceManager.getDefaultSharedPreferences(this);
        
        setupScreenLight();
        setupCameraShortcut();
    }

    private void initializeComponents() {
        flashlightButton = findViewById(R.id.flashlightButton);
        brightnessSlider = findViewById(R.id.brightnessSlider);
        cameraManager = (CameraManager) getSystemService(CAMERA_SERVICE);
        
        try {
            cameraId = cameraManager.getCameraIdList()[0];
        } catch (CameraAccessException e) {
            showError("Camera not available");
            return;
        }

        flashlightButton.setOnClickListener(v -> toggleFlashlight());
        
        // Set initial slider values
        brightnessSlider.setValue(1.0f);
        brightnessSlider.addOnChangeListener((slider, value, fromUser) -> {
            if (isFlashlightOn) {
                toggleFlashlight();  // Turn off
                toggleFlashlight();  // Turn on with new brightness
            }
        });
    }

    private void toggleFlashlight() {
        try {
            isFlashlightOn = !isFlashlightOn;
            if (isFlashlightOn) {
                float brightness = brightnessSlider.getValue();
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                    int maxLevel = cameraManager.getTorchStrengthLevel(cameraId);
                    int level = Math.max(1, Math.min(maxLevel, (int) brightness));
                    cameraManager.turnOnTorchWithStrengthLevel(cameraId, level);
                } else {
                    cameraManager.setTorchMode(cameraId, true);
                }
            } else {
                cameraManager.setTorchMode(cameraId, false);
            }
            
            flashlightButton.setIconTint(getColorStateList(isFlashlightOn ? 
                android.R.color.holo_blue_bright : 
                android.R.color.darker_gray));
                
        } catch (CameraAccessException e) {
            showError("Failed to toggle flashlight");
            isFlashlightOn = false;
        }
    }

    private void showError(String message) {
        Snackbar.make(findViewById(android.R.id.content), message, Snackbar.LENGTH_LONG).show();
    }

    private void setupModes() {
        modeToggleGroup.addOnButtonCheckedListener((group, checkedId, isChecked) -> {
            if (isChecked) {
                stopAllModes();
                if (checkedId == R.id.strobeMode) {
                    startStrobeMode();
                } else if (checkedId == R.id.sosMode) {
                    startSosMode();
                }
            }
        });
    }

    private void startStrobeMode() {
        isStrobeMode = true;
        strobeRunnable = new Runnable() {
            @Override
            public void run() {
                toggleFlashlight();
                if (isStrobeMode) {
                    handler.postDelayed(this, 100);
                }
            }
        };
        handler.post(strobeRunnable);
    }

    private void startSosMode() {
        isSosMode = true;
        sosRunnable = new Runnable() {
            @Override
            public void run() {
                // SOS pattern: ... --- ...
                playSosPattern();
                if (isSosMode) {
                    handler.postDelayed(this, 3000);
                }
            }
        };
        handler.post(sosRunnable);
    }

    private void playSosPattern() {
        long[] pattern = {
            200,200,200,  // ...
            500,          // pause
            500,500,500,  // ---
            500,          // pause
            200,200,200   // ...
        };
        
        for (int i = 0; i < pattern.length; i++) {
            handler.postDelayed(() -> toggleFlashlight(), 
                pattern[i] * i);
        }
    }

    private void stopAllModes() {
        isStrobeMode = false;
        isSosMode = false;
        if (strobeRunnable != null) handler.removeCallbacks(strobeRunnable);
        if (sosRunnable != null) handler.removeCallbacks(sosRunnable);
    }

    private void startAutoOffTimer(int minutes) {
        if (minutes > 0) {
            autoOffTimer = minutes * 60;
            updateTimerDisplay();
            timerRunnable = new Runnable() {
                @Override
                public void run() {
                    if (autoOffTimer > 0) {
                        autoOffTimer--;
                        updateTimerDisplay();
                        handler.postDelayed(this, 1000);
                    } else {
                        if (isFlashlightOn) toggleFlashlight();
                    }
                }
            };
            handler.post(timerRunnable);
        }
    }

    private void updateTimerDisplay() {
        if (autoOffTimer > 0) {
            timerText.setVisibility(View.VISIBLE);
            timerText.setText(String.format("%02d:%02d", 
                autoOffTimer / 60, autoOffTimer % 60));
        } else {
            timerText.setVisibility(View.GONE);
        }
    }

    private void updateBatteryLevel() {
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = registerReceiver(null, filter);
        
        int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        
        float batteryPct = level * 100 / (float)scale;
        batteryLevel.setText(String.format("Battery: %.0f%%", batteryPct));
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (isFlashlightOn) {
            try {
                cameraManager.setTorchMode(cameraId, false);
                isFlashlightOn = false;
            } catch (CameraAccessException e) {
                showError("Failed to turn off flashlight");
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopAllModes();
        if (timerRunnable != null) handler.removeCallbacks(timerRunnable);
    }

    private void setupScreenLight() {
        screenLight = findViewById(R.id.screenLight);
        String color = prefs.getString("screen_color", "#FFFFFF");
        screenLight.setBackgroundColor(Color.parseColor(color));
    }

    private void setupCameraShortcut() {
        flashlightButton.setOnLongClickListener(v -> {
            if (prefs.getBoolean("camera_shortcut", false)) {
                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);
                return true;
            }
            return false;
        });
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            long curTime = System.currentTimeMillis();
            if ((curTime - lastShakeTime) > 1000) {
                float x = event.values[0];
                float y = event.values[1];
                float z = event.values[2];
                
                double acceleration = Math.sqrt(Math.pow(x, 2) +
                                             Math.pow(y, 2) +
                                             Math.pow(z, 2))
                                    - SensorManager.GRAVITY_EARTH;
                
                if (acceleration > SHAKE_THRESHOLD) {
                    lastShakeTime = curTime;
                    if (prefs.getBoolean("shake_to_light", false)) {
                        toggleFlashlight();
                    }
                }
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    private void toggleScreenLight() {
        if (prefs.getBoolean("screen_flash", false)) {
            screenLight.setVisibility(
                screenLight.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
            if (screenLight.getVisibility() == View.VISIBLE) {
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            } else {
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (prefs.getBoolean("shake_to_light", false)) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        }
        updateFromPreferences();
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    private void updateFromPreferences() {
        if (prefs.getBoolean("battery_saver", false)) {
            int batteryPct = getBatteryPercentage();
            if (batteryPct < 20) {
                brightnessSlider.setValue(1);
            }
        }
    }

    private int getBatteryPercentage() {
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = registerReceiver(null, filter);
        int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        return (int) ((level / (float) scale) * 100);
    }
}